#include <stdio.h>

unsigned long original_checks = 0, redesigned_checks = 0;

int original_prime(unsigned long n) {
    original_checks = 0;
    if (n < 2) return 0;
    for (unsigned long i = 2; i <= n / i; i++) {
        original_checks++;
        if (n % i == 0) return 0;
    }
    return 1;
}

/* Redesign: test 2 once, then skip every even candidate divisor. */
int redesigned_prime(unsigned long n) {
    redesigned_checks = 0;
    if (n < 2) return 0;
    if (n == 2) return 1;
    redesigned_checks++;
    if (n % 2 == 0) return 0;

    for (unsigned long i = 3; i <= n / i; i += 2) {
        redesigned_checks++;
        if (n % i == 0) return 0;
    }
    return 1;
}

int main(void) {
    unsigned long values[] = {97, 100, 7919, 1000003};
    int len = (int)(sizeof values / sizeof values[0]);
    puts("Number     Original divisions   Redesigned divisions");
    for (int k = 0; k < len; k++) {
        int a = original_prime(values[k]);
        unsigned long old_count = original_checks;
        int b = redesigned_prime(values[k]);
        printf("%-10lu %-20lu %-20lu %s\n", values[k], old_count,
               redesigned_checks, (a == b) ? "same result" : "ERROR");
    }
    return 0;
}
