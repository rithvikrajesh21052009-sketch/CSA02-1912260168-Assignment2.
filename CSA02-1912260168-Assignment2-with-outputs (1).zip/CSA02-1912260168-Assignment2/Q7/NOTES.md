# Q7

Prime-checking redesign that skips even divisors.

Compile with `gcc -std=c11 -Wall -Wextra -pedantic Q7/Q7.c -o Q7/Q7`. Run the executable and save a genuine screenshot of the output in this folder. Record the exact inputs and counts in your report.
