# Q1

Arithmetic precedence, associativity, discount and GST calculation.

Compile with `gcc -std=c11 -Wall -Wextra -pedantic Q1/Q1.c -o Q1/Q1`. Run the executable and save a genuine screenshot of the output in this folder. Record the exact inputs and counts in your report.
