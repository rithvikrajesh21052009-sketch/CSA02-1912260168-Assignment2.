#include <stdio.h>

int main(void) {
    double price, qty, senior;
    double gross, discount, tax, total, net;

    printf("Enter unit price, quantity and senior status (1=yes, 0=no): ");
    if (scanf("%lf %lf %lf", &price, &qty, &senior) != 3) return 1;

    gross = price * qty;
    discount = senior ? gross * 15.0 / 100.0 : 0.0;
    tax = gross * 5.0 / 100.0; /* Tax is calculated on gross as specified. */
    total = gross - discount + tax;
    net = total > 1000.0 ? total - 50.0 : total;

    printf("Gross = %.2f\nDiscount = %.2f\nGST = %.2f\nTotal = %.2f\nNet = %.2f\n",
           gross, discount, tax, total, net);
    return 0;
}
