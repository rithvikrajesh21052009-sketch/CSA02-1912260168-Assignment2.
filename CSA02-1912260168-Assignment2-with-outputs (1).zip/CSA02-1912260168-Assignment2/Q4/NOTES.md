# Q4

Grade classification using if-else and switch.

Compile with `gcc -std=c11 -Wall -Wextra -pedantic Q4/Q4.c -o Q4/Q4`. Run the executable and save a genuine screenshot of the output in this folder. Record the exact inputs and counts in your report.
