# Q2

Short-circuit evaluation and verification-function call counting.

Compile with `gcc -std=c11 -Wall -Wextra -pedantic Q2/Q2.c -o Q2/Q2`. Run the executable and save a genuine screenshot of the output in this folder. Record the exact inputs and counts in your report.
