#include <stdio.h>

static unsigned long calls = 0;

int verify_card(int passenger_id) {
    calls++;
    /* Simulated server verification: IDs divisible by 10 have a valid card. */
    return passenger_id % 10 == 0;
}

int main(void) {
    int senior, eligible, disability;
    int result;

    printf("Enter senior (0/1), eligible class (0/1), disability card (0/1): ");
    if (scanf("%d %d %d", &senior, &eligible, &disability) != 3) return 1;

    calls = 0;
    result = (senior && eligible) || disability;
    printf("Concession = %s; verification calls in this expression = %lu\n",
           result ? "YES" : "NO", calls);

    /* Explicit short-circuit example: verify only if earlier checks fail. */
    calls = 0;
    result = (senior && eligible) || (disability && verify_card(10));
    printf("Concession with verification = %s; verification calls = %lu\n",
           result ? "YES" : "NO", calls);

    /* Compare logical && with bitwise &: both operands of & are evaluated. */
    calls = 0;
    result = senior & verify_card(10);
    printf("Bitwise &: result = %d; verification calls = %lu\n", result, calls);
    return 0;
}
