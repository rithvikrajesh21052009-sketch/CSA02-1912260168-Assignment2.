# Q6

Reducing-balance loan schedule with repayment and termination safeguards.

Compile with `gcc -std=c11 -Wall -Wextra -pedantic Q6/Q6.c -o Q6/Q6`. Run the executable and save a genuine screenshot of the output in this folder. Record the exact inputs and counts in your report.
