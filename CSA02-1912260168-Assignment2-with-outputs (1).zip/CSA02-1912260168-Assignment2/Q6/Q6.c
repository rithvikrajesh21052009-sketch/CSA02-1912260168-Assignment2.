#include <stdio.h>

int main(void) {
    double principal, rate_percent, repayment;
    double balance, total_interest = 0.0;
    int month = 0;
    const int MAX_MONTHS = 360;

    printf("Enter principal, monthly interest rate (%%), fixed repayment: ");
    if (scanf("%lf %lf %lf", &principal, &rate_percent, &repayment) != 3)
        return 1;
    if (principal <= 0 || rate_percent < 0 || repayment <= 0) {
        printf("Invalid input.\n");
        return 1;
    }

    double rate = rate_percent / 100.0;
    if (rate > 0 && repayment <= principal * rate) {
        printf("Repayment does not exceed the first month's interest; loan will not decrease.\n");
        return 0;
    }

    balance = principal;
    printf("Month  Opening      Interest    Payment     Closing\n");
    while (balance > 0.005) {
        if (month >= MAX_MONTHS) {
            printf("Safety limit reached: balance remains %.2f\n", balance);
            return 0;
        }
        month++;
        double interest = balance * rate;
        total_interest += interest;
        double due = balance + interest;
        double payment = repayment < due ? repayment : due;
        balance = due - payment;
        if (balance < 0.005) balance = 0.0;
        printf("%5d  %10.2f  %10.2f  %10.2f  %10.2f\n",
               month, due - interest, interest, payment, balance);
    }
    printf("Months = %d\nTotal interest = %.2f\n", month, total_interest);
    return 0;
}
