#include <stdio.h>

unsigned long checks = 0;

int is_prime(unsigned long n) {
    checks = 0;
    if (n < 2) return 0;
    for (unsigned long i = 2; i <= n / i; i++) {
        checks++;
        if (n % i == 0) return 0;
    }
    return 1;
}
int is_prime_naive(unsigned long n, unsigned long *count) {
    *count = 0;
    if (n < 2) return 0;
    for (unsigned long i = 2; i < n; i++) {
        (*count)++;
        if (n % i == 0) return 0;
    }
    return 1;
}
int is_prime_while(unsigned long n, unsigned long *count) {
    *count = 0;
    if (n < 2) return 0;
    unsigned long i = 2;
    while (i <= n / i) {
        (*count)++;
        if (n % i == 0) return 0;
        i++;
    }
    return 1;
}
int is_prime_do(unsigned long n, unsigned long *count) {
    *count = 0;
    if (n < 2) return 0;
    unsigned long i = 2;
    do {
        if (i > n / i) break;
        (*count)++;
        if (n % i == 0) return 0;
        i++;
    } while (1);
    return 1;
}
int main(void) {
    unsigned long tickets[] = {2, 3, 97, 100, 7919, 1000003};
    int len = (int)(sizeof tickets / sizeof tickets[0]);
    for (int k = 0; k < len; k++) {
        unsigned long naive_count, while_count, do_count;
        int p = is_prime(tickets[k]);
        unsigned long improved_count = checks;
        is_prime_naive(tickets[k], &naive_count);
        is_prime_while(tickets[k], &while_count);
        is_prime_do(tickets[k], &do_count);
        printf("%8lu %-9s improved=%lu naive=%lu while=%lu do-while=%lu\n",
               tickets[k], p ? "prime" : "not prime",
               improved_count, naive_count, while_count, do_count);
    }
    return 0;
}
