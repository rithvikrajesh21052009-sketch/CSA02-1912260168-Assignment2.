# Q5

Prime checking with naive, for, while and do-while implementations.

Compile with `gcc -std=c11 -Wall -Wextra -pedantic Q5/Q5.c -o Q5/Q5`. Run the executable and save a genuine screenshot of the output in this folder. Record the exact inputs and counts in your report.
