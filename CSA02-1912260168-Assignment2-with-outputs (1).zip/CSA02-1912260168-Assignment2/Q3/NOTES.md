# Q3

Bitwise set, clear, toggle, test and binary display.

Compile with `gcc -std=c11 -Wall -Wextra -pedantic Q3/Q3.c -o Q3/Q3`. Run the executable and save a genuine screenshot of the output in this folder. Record the exact inputs and counts in your report.
